var collection = require('../utilities/connection');
var ticketDb = {}

ticketDb.generateId = () => {
    return collection.getCollection().then(function (collection) {
        return collection.distinct("ticket.ticketId").then((ticketId) => {
            var max_ticket_Id = Math.max(...ticketId);
            if (max_ticket_Id > 0)
                return max_ticket_Id + 1;
            else
                return 1001
        })

    })
}


ticketDb.bookTicket =  (emailId,booking) => {
    return ticketDb.generateId().then( (id) => {
        booking.ticketId=id
    return collection.getCollection().then( (database) => {
            return database.updateOne({"emailId":emailId},
            {$push: {
                ticket: booking
            }
          }).then( (booked) => {
              console.log(booked.nModified)
            if (booked.nModified == 1){
                return booking
            }  
                    else
                        return null
        })
    })
})
}


ticketDb.fetchBooking =  (emailId) => {
    return collection.getCollection().then( (database) => {
        return database.findOne({ "emailId": emailId }).then(function (data) {
            console.log("in models", typeof(data))
            return data;
        })
    })
}

ticketDb.deleteBooking =  (emailId) => {
    return collection.getCollection().then( (database) => {
        return database.findOne({ "emailId": emailId }).then(function (data) {
            console.log("in models", data.ticket)
            
        })
    })
}

module.exports = ticketDb;