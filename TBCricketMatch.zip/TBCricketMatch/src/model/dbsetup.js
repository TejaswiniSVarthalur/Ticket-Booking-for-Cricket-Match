var today = new Date();
var year = today.getFullYear();
var month = today.getMonth();
var day = today.getDate();

collectionDocument = [
    {
        emailId: 'abc@infy.com',

        "ticket": [{
            groundName: 'SaltLakeStadium',
            bookedOn: new Date(year,month+3,day),
            price: 4000,
            noOfTickets: 2,
            ticketId: 1001,
            typeOfTicket : 'Orchestra'
        },
        {
            groundName: 'ChinnaswamyStadium',
            bookedOn: new Date(year,month+1,day),
            price: 3500,
            noOfTickets: 3,
            ticketId: 1002,
            typeOfTicket : 'Mezzanine'
        }
        ]
    },
    {

        emailId: 'def@infy.com',

        "ticket": [{
            groundName: 'KalooInternationalStadium',
            bookedOn: new Date(year,month,day),
            price: 3000,
            noOfTickets: 1,
            ticketId: 1003,
            typeOfTicket : 'Orchestra'
        },
        {
            groundName: 'ChinnaswamyStadium',
            bookedOn: new Date(year,month+1,day),
            price: 5000,
            noOfTickets: 5,
            ticketId: 1004,
            typeOfTicket : 'Balcony'
        }
        ]
    },
]


var collection = require('../utilities/connection');

exports.setupDb = () => {
    return collection.getCollection().then((myCollection) => {
        return myCollection.deleteMany().then((data) => {
            return myCollection.insertMany(collectionDocument).then((data) => {
                if (data) {
                    return "Insertion Successfull"
                } else {
                    throw new Error("Insertion failed")
                }
            })
        })

    })
}