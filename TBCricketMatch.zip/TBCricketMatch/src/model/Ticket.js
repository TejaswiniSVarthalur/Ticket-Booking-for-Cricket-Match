class Ticket{
    constructor(obj){
    this.ticketId=obj.ticketId
    this.groundName=obj.groundName;
    this.bookedOn = obj.bookedOn;
    this.price = obj.price;
    this.noOfTickets = obj.noOfTickets;
    this.typeOfTicket = obj.typeOfTicket
}
}
module.exports = Ticket;