var Validator = {}


Validator.validateDate = (bookingDate) => {
    var today = new Date();
    var bDate = new Date(bookingDate);
    if (bDate <today) {
        let err = new Error("Booking date cannot be before today")
        err.status = 406;
        throw err;
    }
}
// Validator.validateTicketId = (ticketId) => {
//     var ticketId=ticketId;
//     if(!ticketId.match(/^[T][1-9]{4}$/)){
//         let err = new Error("Please enter a valid ticket id");
//         err.status = 406;
//         throw err
//     }
// }


module.exports = Validator;